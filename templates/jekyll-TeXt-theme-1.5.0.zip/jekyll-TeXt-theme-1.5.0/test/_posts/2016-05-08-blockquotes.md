---
layout: post
title: Jekyll - Blockquotes
key: 20160508
tags: Jekyll English
---

> "There is nothing either good or bad, but thinking makes it so."
>
> —Hamlet in *Hamlet*

<!--more-->

**markdown:**

    > "There is nothing either good or bad, but thinking makes it so."
    >
    > —Hamlet in *Hamlet*

---

> "From women's eyes this doctrine I derive:
>
> They sparkle still the right Promethean fire;
>
> They are the books, the arts, the academes,
>
> That show, contain, and nourish all the world."
>
> —Berowne in *Love's Labor's Lost*

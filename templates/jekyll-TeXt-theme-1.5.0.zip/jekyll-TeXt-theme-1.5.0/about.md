---
layout: page
titles:
  en: About
  zh: 关于
  zh-Hans: 关于
  zh-Hant: 關於
key: page-about
---

Welcome to my blog! :earth_asia: :earth_africa: :earth_americas:

{% highlight javascript %}
(() => console.log('hello, world!'))();
{% endhighlight %}

## Skills

- HTML5, CSS3(SASS), JavaScript(ES2017, Node.js), Bash(Zsh)
- React, React Native, Vue.js
- gulp, webpack
- Adobe Photoshop, Sketch